#! /usr/bin/env python 
# Imported Packages
import rospy 
import numpy as np 
import random
import matplotlib.pyplot as plt
from geometry_msgs.msg import Twist  #import msg data type "Twist" to be published
from nav_msgs.msg import Odometry     #import msg data type "Odometry" to be subscribed

#Initialization
position = np.zeros((1,3))	#Identify array of six elements all initialized by zero
position_Noise = np.zeros((1,3)) #Create an array to have the noisy measurments
#Intialization of the arrays that will contian the values of real data and noisy 
X_Sensor = [] #Array to hold value of x obtained by the sensor
Y_Sensor = [] #Array to hold value of y obtained by the sensor
Theta_Sensor = [] #Array to hold value of theta obtained by the sensor

X_noisy = [] #Array to hold noisy value of x coordinates
Y_noisy = [] #Array to hold noisy value of y coordinates
Theta_noisy = [] #Array to hold noisy value of theta coordinates

# Standard Deviation Inputs
SD = [0.1,0.1,0.1]
#define the message that will be Published
Pose_msg = Twist()

#Callback function which is called when a new message of type Odometry is received by the subscriber
def callback(msg):
    global position
    global Pose_msg

    # Extract the x,y and theta
    x = round(msg.pose.pose.position.x, 4)		
    y = round(msg.pose.pose.position.y, 4)	
    Theta = round(msg.twist.twist.angular.z, 4)
    X_Sensor.append(x)
    Y_Sensor.append(y)
    Theta_Sensor.append(Theta)
    
    
    #Save the positions in an array
    position = [x, y, Theta] 

    #Call the add noise function.
    Position_Noise = add_Noise(position)
    X_noisy.append(Position_Noise[0])
    Y_noisy.append(Position_Noise[1])
    Theta_noisy.append(Position_Noise[2])

    Pose_msg.linear.x = round(Position_Noise[0],4)
    Pose_msg.linear.y = round(Position_Noise[1],4)
    Pose_msg.angular.z = round(Position_Noise[2],4)


    pub.publish(Pose_msg)	#Publish msg



def add_Noise(position):
	global SD
	global position_Noise

	x_noise = position[0] + random.uniform(-SD[0],SD[0])		#Noisy data calculated at x
	y_noise = position[1] + random.uniform(-SD[1],SD[1])		#Noisy data calculated at y
	theta_noise = position[2] + random.uniform(-SD[2],SD[2])	#Noisy data calculated at theta

	position_Noise = [x_noise, y_noise, theta_noise]   #Store the noisy position in array
 
	return(position_Noise)


if __name__ == '__main__':     # Main function that is executed 

	# Initialize ROS Node 
	rospy.init_node('Turtle_Noise', anonymous = True) #Identify Ros Node
	# Initialize The Subscriber
	sub = rospy.Subscriber('/odom', Odometry, callback) #Subscribe to the  topic "/turtle1/pose" to read the turtle coordinates
	# Initialize The Publisher
	pub = rospy.Publisher('/Turtle_Noise_Position', Twist, queue_size=10) #Publish the New Noisy message
	rospy.spin()


	#Plotting of signals from sensor and noisy signals
	plt.figure(1)
	line_1 = plt.plot(X_Sensor, 'r-', label='X-Model')
	line_2 = plt.plot(X_noisy, 'b-', label='X-Noisy')
	plt.legend()


	plt.figure(2)
	line_1 = plt.plot(Y_Sensor, 'r-', label='Y-Model')
	line_2 = plt.plot(Y_noisy, 'b-', label='Y-Noisy')
	plt.legend()

	plt.figure(3)
	line_1 = plt.plot(Theta_Sensor, 'r-', label='Theta-Model')
	line_2 = plt.plot(Theta_noisy, 'b-', label='Theta-Noisy')
	plt.legend()
	
	plt.show(block=True)



